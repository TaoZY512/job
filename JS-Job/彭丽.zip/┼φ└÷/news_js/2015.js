(function () {
    var content_list = document.querySelector(".content-list");
    networking({
        url:"./JSON/fruit.json",
        success:function (news) {
            loadingNewsHtml(content_list,news.news_threes)
        }
    })
})()