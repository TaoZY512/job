(function () {
    //注册bmob服务
    Bmob.initialize("6f0732aa068f6556bf2fd13d4cd26666","ec0c9c599f143e3b0b8f93ae7d6edd7d");
    //记录登录/注册
    var isLogin =true;
    location.hash = "login";
    var go_register = getEl(".go-register"),
        go_login = getEl(".go-login"),
        register = getEl(".register",true),
        input = getEl(".input-box input",true),
        input_box = getEl(".input-box",true),
        login = getEl(".login"),
        title = getEl(".title"),
        login_register_btn = getEl(".login-register-btn"),
        validataCode = getEl(".validate-code-img"),
        validate = getEl(".validate-code");
    //点击前往注册
    go_register.onclick = function () {
        isLogin = false;
        register[0].className = "input-box register";
        register[1].className = "input-box register";
        login.className = "hidden";
        title.textContent = "REGISTER";
        login_register_btn.textContent = "注册";
        location.hash = "register";
        document.title = "君子谷注册";
        go_register.className = "hidden";
        go_login.className = "register";
        input_box[2].className = "hidden"
    }
    //点击前往登录
    go_login.onclick = function () {
        isLogin = true;
        register[0].className = "hidden";
        register[1].className = "hidden";
        input_box[2].className = "input-box validate";
        login.className = "fl go-register";
        title.textContent = "LOGIN";
        login_register_btn.textContent = "登录";
        location.hash = "login";
        go_register.className = "fr register";
        go_login.className = "hidden";
    }
    //验证填写内容是否有错误
    inputOnblur(input);
    var username = getEl(".username"),
        password = getEl(".password"),
        email = getEl(".email"),
        tel = getEl(".tel");
    login_register_btn.onclick = function  () {
        loginOnclick(isLogin,input,username,password,validate,email,tel);
    }
    //获取存储验证码元素
    //设置默认验证码
    validataCode.textContent = getVerificationCode(6);
    //点击验证码/切换
    validataCode.onclick = function () {
        validataCode.textContent = getVerificationCode(6);
    }
    //判断验证码是否输入正确
    validate.onblur = function () {
        //根据验证码生成正则表达式
        //i 忽略大小写
        var reg = new RegExp(`^${validataCode.textContent}$`,"i");
        //通过正则表达式判断验证码是否输入正确
        if(!reg.test(this.value)){
            validate.parentElement.classList.add("error");
        }else {
            validate.parentElement.classList.remove("error");
        }
    }
})()