//轮播
(function () {
    var oPrev      = getEl(".prev"),
        oNext      = getEl(".next"),
        oIssues    = getEl(".issues"),
        oTimeline = getEl(".time"),
        oDots     = getEl(".dots", true);
    var curIndex = 0,
        maxIndex = 11,
        isAnimating = false,
        timer = null;
    oPrev.onclick = function() {
        if(isAnimating) {return;}
        if(curIndex == 0) {
            curIndex = maxIndex
        }else {
            --curIndex;
        }
        tab(+oTimeline.offsetWidth,isAnimating,oIssues,oTimeline);
        changeIdot(oDots,curIndex);
        changeIdots(oDots,curIndex);
    };
    oNext.onclick = function() {
        if(isAnimating) {return;}
        if(curIndex == maxIndex) {
            curIndex = 0
        }else {
            ++curIndex;
        }
        tab(-oTimeline.offsetWidth,isAnimating,oIssues,oTimeline);
        changeIdot(oDots,curIndex);
        changeIdots(oDots,curIndex);
    }
    for(var i = 0, len = oDots.length; i < len; i++) {
        // 动态设置小圆点下标
        // data-index = ...
        oDots[i].dataset.index = i;
        oDots[i].onclick = function() {
            var tarIndex = this.dataset.index;
            if(tarIndex == curIndex || isAnimating) {
                return;
            }
            var offset = -oTimeline.offsetWidth * (tarIndex - curIndex);
            // 更新当前下标位置
            curIndex = tarIndex;
            tab(offset,isAnimating,oIssues,oTimeline);
            changeIdot(oDots,curIndex);
            changeIdots(oDots,curIndex);
        }
    }
    play();
    oTimeline.onmouseenter = stop;
    oTimeline.onmouseleave = play;
    function play() {
        timer = setInterval(function(){
            oNext.onclick();
        }, 3000);
    }
    function stop() {
        clearInterval(timer);
        timer = null;
    }

})();
