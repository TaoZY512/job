(function () {
        var oFruit = getEl(".fruit");
        var oContainer = document.querySelector("#page-box");
        var data = '';
        //加载json数据
        networking({
            url:"./JSON/fruit.json",
            success:function (fruits) {
                data = fruits.fruit;
                //分页
                new LHYPage({
                    container: oContainer,
                    curPage: 1,
                    allPage: Math.ceil(data.length/9),
                    callBack: function(curPage) {
                        loadingHtml(oFruit,data,curPage);
                    }
                });
            }
        });
        var btnSearch = document.getElementById('btnSearch');
        btnSearch.onclick = function () {
            var oFruit = getEl(".fruit");
            // 清空tbody
            oFruit.innerHTML = '';
            // 获取输入框当前的值
            var searchVal = document.getElementById('searchVal').value;
            if(searchVal !== "") {
                // 返回符合条件组成的数组
                var filterResult = data.filter(function (item) {
                    // 将正则匹配结果为true的对象添加到一个数组并在filter循环结束后返回该数组
                    return new RegExp(searchVal, 'i').test(item.name);
                });
                // 加载搜索后的数据
                if(filterResult.length == 0){
                    alert("对不起，暂时没有该野果")
                    loadingHtml(oFruit,data,"1");
                }else {
                    loadingHtml(oFruit,filterResult,"1");
                }
            } else {
                alert('请先输入野果名称');
                // 加载原始数据
                loadingHtml(oFruit,data,"1");
            }
        }
})();

