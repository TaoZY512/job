//jQuery 文档就绪函数
$(function () {
    //记录当前显示页面下标
    var curIndex;
    //定义路由地址
    var links = [
        "./pages/2017.html",
        "./pages/2016.html",
        "./pages/2015.html",
        "./pages/2014.html",
        "./pages/2013.html",
        "./pages/2012.html"
    ]
    //为菜单项添加点击事件
    $(".tabBar-item").on("click",function () {
        $(this).addClass("show-time");
        $(this).siblings().removeClass("show-time");
        var index = $(this).index();
        //避免用户重复点击
        if(index == curIndex){return};
        //更新当前显示页面下标
        curIndex = index;
        //jQuery提供的ajax请求方法
        $.ajax({
            url:links[$(this).index()],
            type:"GET",
            //请求成功回调
            success:function (response) {
                $("#content").html(response);
            }
        });
        //trigger触发一次
    }).first().trigger("click");
})