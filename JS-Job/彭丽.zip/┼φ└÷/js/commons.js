/*
    @description 获取随机验证码
    @param  length String 验证码长度
    @return return String随机字符
 */
//验证码
function getVerificationCode(length) {
    //定义随机源
    var str = '';
    str += "qwertyuiopasdfghjklzxcvbnm";
    str += "QWERTYUIOPASDFGHJKLZXCVBNM";
    str += "1234567890";
    //获取随机下标
    var resStr = "";
    for (var i = 0; i <length;i++){
        var index = Math.floor(Math.random()*str.length);
        //resStr += str.[index]
        resStr += str.slice(index,index + 1);
    }
    return resStr;
}
//注册的正则表达式
function  Validate(type,str) {
    var res = null;
    switch (type) {
        case "username": {
            // 1. 用户名正则，4到16位（字母，数字，下划线，减号）
            res = /^[A-Za-z0-9_-]{4,16}$/.test(str);
        } break;
        case "password": {
            // 2. 用户名正则，4到16位（字母，数字，下划线，减号）
            res = /^[A-Za-z0-9_-]{4,16}$/.test(str);
        } break;
        case "email": {
            // 3. 邮箱
            res = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(str);
        } break;
        case "tel": {
            // 4. 手机
            res = /^1[3|4|5|8][0-9]\d{4,8}$/.test(str);
        } break;
    }
    return res;
}
function getEl(Sel, isAll) {
    if(isAll) {
        return document.querySelectorAll(Sel);
    }else {
        return document.querySelector(Sel);
    }
}
function getStyle(el, attr) {
    if(el.currentStyle) {
        return el.currentStyle[attr];
    }else {
        return getComputedStyle(el, null)[attr];
    }
}
//请求json文件
function networking(options) {
    if(!options.url){
        throw "networking:缺乏url参数";
    }
    //默认设置
    options.method = options.method || "GET";
    options.parameter = options.parameter || {};
    //创建请求对象
    var xhr = new XMLHttpRequest();
    //配置请求对象
    xhr.open(options.method,options.url,true);
    xhr.timeout = 10;
    xhr.responseType = "json";
    //发送请求
    xhr.send(options.parameter);
    //添加事件监听
    xhr.onload = function () {
        if((xhr.status >= 200 & xhr.status <300) || xhr.status == 304){
            options.success && options.success(xhr.response);
        }
    }
}
//野果打印在页面上
function  loadingHtml(parent,data,curIndex) {
    //获取总页码
    var totalPage = Math.ceil(data.length /9);
    var starIndex = (curIndex - 1)*9;
    var endIndex  = curIndex == totalPage ? data.length : starIndex + 9;
    var htmlStr = '';
    for (var i = starIndex; i < endIndex; i++) {
        htmlStr += `
                <li>
                    <img src="${data[i].img}" alt="">
                    <p class="name-p">${data[i].name}</p>
                    <p>${data[i].Eng_name}</p>
                </li>
            `
    }
    parent.innerHTML = htmlStr;
}
//新闻资讯打印在页面上
function loadingNewsHtml(parent,data) {
    var htmlStr = '';
    for (var i = 0; i < data.length; i++) {
        htmlStr += `
                <li class="clearFix">
        <img src="${data[i].img}" alt="">
        <div class="fr news-title">
            <h1>${data[i].title}</h1>
            <time>${data[i].time}</time>
            <p>${data[i].text}</p>
        </div>
        
    </li>
            `
    }
    parent.innerHTML = htmlStr;
}
//验证填写内容是否有错误
function inputOnblur(input) {
    input[0].onblur = function () {
        var type = input[0].className,
            value = input[0].value;
        if(!Validate(type,value)){
            input[0].parentElement.classList.add("error");
        }else {
            input[0].parentElement.classList.remove("error");
        }
    }
    input[1].onblur = function () {
        var type = input[1].className,
            value = input[1].value;
        if(!Validate(type,value)){
            input[1].parentElement.classList.add("error");
        }else {
            input[1].parentElement.classList.remove("error");
        }
    }
    input[3].onblur = function () {
        var type = input[3].className,
            value = input[3].value;
        if(!Validate(type,value)){
            input[3].parentElement.classList.add("error");
        }else {
            input[3].parentElement.classList.remove("error");
        }
    }
    input[4].onblur = function () {
        var type = input[4].className,
            value = input[4].value;
        if(!Validate(type,value)){
            input[4].parentElement.classList.add("error");
        }else {
            input[4].parentElement.classList.remove("error");
        }
    }
}
//验证是否登陆成功
function loginOnclick(isLogin,input,username,password,validate,email,tel) {
    if (isLogin) {
        var isThough = true;
        for (var i = 0; i < input.length; i++) {
            if (input[i].parentElement.classList.contains("error")) {
                isThough = false;
            }
        }
        if (!username.value || !password.value || !validate.value) {
            alert("请完善信息");
        }else if (!isThough) {
            alert("信息不合法！");
        }else {
            new LHYAlertView({
                type: "alert",
                message: "登录中，请稍后！"
            })
            Bmob.User.logIn(username.value, password.value, {
                success: function () {
                    new LHYAlertView({
                        type: "alert",
                        message: "登陆成功",
                        sureCallBack: function () {
                            sessionStorage.loginState = true;
                            location.href = "./index.html"
                        }
                    })
                },
                error: function () {
                    new LHYAlertView({
                        type: "alert",
                        message: "用户名不存在或密码不对",
                    })
                }
            })
        }
    } else {
        var isThough = true,isEmpty = false;
        for (var i = 0; i < input.length; i++) {
            if (input[i].parentElement.classList.contains("error")) {
                isThough = false;
            }
        }
        if(!username.value || !password.value || !email.value || !tel.value){
            isEmpty = true;
        }
        if (isEmpty) {
            alert("请完善信息！");
        }else if (!isThough) {
            alert("信息不合法！");
        }else {
            var user = new Bmob.User();
            user.set("username", username.value);
            user.set("password", password.value);
            user.set("email", email.value);
            user.set("phone", tel.value);
            user.signUp(null, {
                success: function(user) {
                    new LHYAlertView({
                        type: "alert",
                        message: "注册成功",
                        sureCallBack: function () {
                            sessionStorage.loginState = true;
                            location.href = "./index.html"
                        },
                    });
                },
                error: function (user, error) {
                    var alertMsg = "";
                    switch (error.code){
                        case 202 :{
                            alertMsg = "用户已存在";
                        }break;
                        case 203 :{
                            alertMsg = "邮箱已被注册";
                        }break;
                        case 209 :{
                            alertMsg = "手机已被注册";
                        }break;
                    }
                    new LHYAlertView({
                        type : "default",
                        autoClose:1000,
                        title:"温馨提醒",
                        message:alertMsg
                    })
                }
            });
        }
    }
}
//图片轮播年份的变化
function changeIdot(oDots,curIndex) {
    for(var i = 0, len = oDots.length; i < len; i++) {
        if(oDots[i].classList.contains("show")) {
            oDots[i].classList.remove("show")
            break;
        }
    }
    oDots[curIndex].classList.add("show");
}
function changeIdots(oDots,curIndex) {
    for(var i = 0, len = oDots.length; i < len; i++) {
        if(oDots[i].classList.contains("shows")) {
            oDots[i].classList.remove("shows")
            break;
        }
    }
    oDots[curIndex].classList.add("shows");
}
//图片轮换设置
function tab(offset,isAnimating,oImgBox,oContainer) {
    // 更新动画状态
    isAnimating = true;
    // 帧动画
    var interval = 15,
        duration = 500,
        frames   = duration / interval,
        speed    = Math.ceil(offset / frames);

    var curLeft  = parseInt(getStyle(oImgBox, "left"));
    tarLeft  = curLeft + offset;
    var t = setInterval(function() {
        // 更新当前值
        curLeft  = parseInt(getStyle(oImgBox, "left"));
        // 下一页：offset < 0 && curLeft > tarLeft
        // 上一页：offset > 0 && curLeft < tarLeft

        if((offset < 0 && curLeft > tarLeft) || (offset > 0 && curLeft < tarLeft)) {
            oImgBox.style.left = curLeft + speed + "px";
        }else {
            // 清除定时器
            clearInterval(t);
            t = null;
            isAnimating = false;
            // 更新位置
            oImgBox.style.left = tarLeft + "px";
            // 处理边界值
            var imgW = oContainer.offsetWidth;
            if(parseInt(oImgBox.style.left) < -6 * imgW) {
                oImgBox.style.left = -imgW + "px";
            }else if(parseInt(oImgBox.style.left) > -imgW) {
                oImgBox.style.left = -6 * imgW + "px";
            }
        }
    }, interval);
}