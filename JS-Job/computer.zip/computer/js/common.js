function $(x){
    return document.getElementById(x);
}