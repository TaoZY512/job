let loadingHtml = (parent,response) => {
    let datas = response["goods"];
    let htmlStr = "";
    datas.forEach((data) => {
        htmlStr +=`
        <li><a href="#">
        <section class="one">
         <img src="${data.img}" alt="">
        </section>
        <section>
            <p>${data.model}</p>
            <div class="null"></div>
            <p>${data.price}</p>
        </section>
        
    </a></li>
        `
    })
    parent.html(htmlStr)
}
//动画
function animations() {
   
    let wHeight = window.innerHeight;
    let offset  = document.body.scrollTop || document.documentElement.scrollTop;
    let moveAnimationEls = $(".upload-p");
    let scaleAnimationEls     = $(".upload");
    // console.log(moveAnimationEls[2].offsetTop);
    for(let i = 0; i < moveAnimationEls.length; i++) {
        let moveOffsetTop  = moveAnimationEls[i].offsetTop;
        let scaleOffsetTop = scaleAnimationEls[i].offsetTop;

        if(wHeight + offset > moveOffsetTop) {
            moveAnimationEls[i].classList.add("move");
        }else {
            moveAnimationEls[i].classList.remove("move");
        }
        if(wHeight + offset > scaleOffsetTop) {
            scaleAnimationEls[i].classList.add("scale");
        }else {
            scaleAnimationEls[i].classList.remove("scale");
        }
    }
}
