$(function(){
    //图片轮播
    let run =[];
    setInterval(function(){
      $(".lun-bottom img").toggleClass("show");
    },3000);
   
     //1.获取数据
     $.ajax({
        url:"../json/index.json",
        type:"GET",
        dataType:"json",
        success:(response) => {
             // 2. 加载数据
             loadingHtml($(".commodity-list"), response);
        }
    });
  
   //动画效果
   window.onscroll = function () {
    animations();
   }   
   
});

