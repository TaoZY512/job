$(function(){
  //获取数据
 $.ajax({
     type:"get",
     url:"./json/goods.json",
     success:function(response){
         data = response.goods;
         
         let textHtml = "";
        for(var i = 0,len = data.length;i<len;i++){
            textHtml += `
        <li>
               <a href="javascript:;">
               <img src="${data[i].imgSrc}" alt=""><br/>
               <p>${data[i].pri}</p>
               <small>${data[i].small}</small>
               </a>
           </li>
        `
        
    }
    console.log(textHtml);
    $(".menu-list").html(textHtml);
     }
 });
 
});
