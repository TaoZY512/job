$(function(){
       $("#productOne").on("click",()=>{
           $("#productTwo").addClass("dis");
           $("#productThree").addClass("dis");
        //    var brother = $(e>p)
           $("#productOne > div").removeClass("dis");
       })
    });

