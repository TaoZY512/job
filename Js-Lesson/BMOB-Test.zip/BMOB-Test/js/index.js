

$(function(){

    location.href = "./pages/login-register.html";

});